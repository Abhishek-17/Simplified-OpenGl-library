/*
Abhishek kumar
201101185
*/

1. to compile use make.
2. to run use " optirun ./assign_openglpipeline "
3. Ply file generated is PLY_201101185.ply
4. All sgl functions are in sgl.h
